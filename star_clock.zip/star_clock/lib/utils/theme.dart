class StarTheme {

  var _theme;

  void setTheme(theme) {
    _theme = theme;
  }

  getTheme() {
    return _theme;
  }
}

StarTheme themeStore = StarTheme();
